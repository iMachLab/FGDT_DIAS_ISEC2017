import pandas as pd
import numpy as np
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt
from sklearn.cross_validation import train_test_split
from sklearn.cross_validation import KFold
from math import exp

#This is the definition of the training and classifying function
#This takes X_train,X_test,y_train,y_test
#kf is the k-means split which contains train_set and cross_validation_set split indices
#classifier is the classifier used. Either decision tree or random forest.
def runClassifier(X_test, X_train, y_test, y_train, kf, classifier):

    for k, (train_index, test_index) in enumerate(kf):
        #Setting variables so Code is more readable
        X_train_CV = X_train[train_index]
        X_test_CV = X_train[test_index]
        y_train_CV = y_train[train_index]
        y_test_CV = y_train[test_index]

        #Fitting the Tree
        classifier.fit(X_train_CV,y_train_CV)
        #For Cross Validation Set
        predictions = classifier.predict(X_test_CV)

        sum = 0;    #Variable to find number of correct predictions
        for i in range(len(predictions)):
            if (predictions[i] == y_test_CV[i]):
                sum = sum + 1;
        CV_accuracy = sum*1.0/(len(y_test_CV))

        #For Test Set
        predictions = classifier.predict(X_test)
        sum = 0    #Variable to find number of correct predictions
        for i in range(len(predictions)):
            if(predictions[i] == y_test[i]):
                sum = sum+1
        Test_accuracy = sum * 1.0 / (len(y_test))

        print("\tRUN ", k+1 , ": CV Accuracy = ", CV_accuracy, "\t Test Accuracy = ", Test_accuracy)
