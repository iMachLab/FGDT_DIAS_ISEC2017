import pandas as pd
import numpy as np
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt
from sklearn.cross_validation import train_test_split
from sklearn.cross_validation import KFold
from math import exp
import classiier as cf

#plt.ion()  #Making matplotlib interactive so terminal does not hang
#plt.interactive(True)
######################### Setting Variables ####################################
scale = 1 #Set = 1 if you want to use StandardScaler before growing trees and forests
local_test_size = 0.2 #train_test_split size
kFold = 5 #Set number of folds in KFold
################################################################################

#This is the definition of the training and classifying function
#This takes X_train,X_test,y_train,y_test
#kf is the k-means split which contains train_set and cross_validation_set split indices
#classifier is the classifier used. Either decision tree or random forest.

##################### End of Function Definition ############################
def guassianFunction(x,a,b,c):
    guassian = np.zeros(x.shape);
    for i in range(x.size):
        guassian[i] = a * exp( -1 * ( x[i] - b )**2 / (2 * c * c))
    return guassian;
############################ Setting up Data ##################################
print('\t\tSetting up Data!')

#opening Sensor Data
with open('HT_Sensor_dataset.dat', 'r') as f:
    next(f)  #skip first row
    df = pd.DataFrame(l.rstrip().split() for l in f)

df = df.as_matrix()   #df contains the dataset.
#col 0 has id_nos, col 1 has time, col 2-9 has sensors r1 to r8
#col 10 has temp, col 11 has humidity.

#opening metadata and converting to usable form
metadata = np.loadtxt('HT_Sensor_metadata.dat', skiprows=1, dtype=str)
metadata[ metadata[:,2] == "b'wine'", 2 ] = 1
metadata[ metadata[:,2] == "b'banana'", 2 ] = 2
metadata[ metadata[:,2] == "b'background'", 2 ] = 0
id_nos = metadata[:,2].astype(np.double)
t0 = metadata[:,3]
dt = metadata[:,4]
#Converting metadata to usable form.
for i in range(len(t0)):
    t0[i] = t0[i][2:-1]
    dt[i] = dt[i][2:-1]

t0 = t0.astype(np.double)
dt = dt.astype(np.double)

#stripping X and y from df
y = df[:,0].astype(np.int);
y_copy = np.copy(y) #Copy needed During FS Set Creation
X = df[:,2:].astype(np.double); #Excluding Time columns, the second column in dataset

#replacing labels of y from id_nos.
for i in range(len(y)):
    y[i] = id_nos[ y[i] ]

X = df[:,2:].astype(np.double); #Excluding Time columns, the second column in dataset



############# End of code to view scatter plot ##########

#initialising all requirements
stdsc = StandardScaler()
tree = DecisionTreeClassifier(criterion='entropy')
forest = RandomForestClassifier(criterion = 'entropy', n_estimators = 10, n_jobs = 2)

############################# Data Load Complete ##############################
print('\t\tData load Complete')
############################# Creating FS Feature Set #########################
print('\t\tCreating FS Feature Set')
beta = np.array([
[-0.0044,		0.00014, 	0.0110],
[-0.0110,		0.00034, 	0.0240],
[-0.0110,		0.00034,	0.0230],
[-0.0110,		0.00033,	0.0230],
[-0.0056, 		0.00018,	0.0086],
[-0.0039,		0.00012,	0.0071],
[-0.0070,		0.00022,	0.0095],
[-0.0057,		0.00020,	0.0029]
])

(rows,cols) = X.shape
X_fs = np.empty([rows-99,18]) #8FS Features + 2 t0 dt Features + 8 RS features
y_fs = np.empty([rows-99])
j=0
for i in range(len(X)):
    if (y_copy[i] != y_copy[i-1]):
        continue
    deltaT = X[i][8] - X[i-1][8]
    deltaH = X[i][9] - X[i-1][9]
    #Copying y Set
    y_fs[j] = y[i]
    #Creating FS Features
    X_fs[j][0] = X[i][0] - X[i-1][0] * exp(beta[0][0] * deltaH + beta[0][1] * deltaH * deltaH + beta[0][2] * deltaH * deltaT)
    X_fs[j][1] = X[i][1] - X[i-1][1] * exp(beta[1][0] * deltaH + beta[1][1] * deltaH * deltaH + beta[1][2] * deltaH * deltaT)
    X_fs[j][2] = X[i][2] - X[i-1][2] * exp(beta[2][0] * deltaH + beta[2][1] * deltaH * deltaH + beta[2][2] * deltaH * deltaT)
    X_fs[j][3] = X[i][3] - X[i-1][3] * exp(beta[3][0] * deltaH + beta[3][1] * deltaH * deltaH + beta[3][2] * deltaH * deltaT)
    X_fs[j][4] = X[i][4] - X[i-1][4] * exp(beta[4][0] * deltaH + beta[4][1] * deltaH * deltaH + beta[4][2] * deltaH * deltaT)
    X_fs[j][5] = X[i][5] - X[i-1][5] * exp(beta[5][0] * deltaH + beta[5][1] * deltaH * deltaH + beta[5][2] * deltaH * deltaT)
    X_fs[j][6] = X[i][6] - X[i-1][6] * exp(beta[6][0] * deltaH + beta[6][1] * deltaH * deltaH + beta[6][2] * deltaH * deltaT)
    X_fs[j][7] = X[i][7] - X[i-1][7] * exp(beta[7][0] * deltaH + beta[7][1] * deltaH * deltaH + beta[7][2] * deltaH * deltaT)
    #Adding t0 and dt features
    X_fs[j][8] = t0[y_copy[i]]
    X_fs[j][9] = dt[y_copy[i]]
    #Adding the Original RS features
    X_fs[j][10] = X[i][0]
    X_fs[j][11] = X[i][1]
    X_fs[j][12] = X[i][2]
    X_fs[j][13] = X[i][3]
    X_fs[j][14] = X[i][4]
    X_fs[j][15] = X[i][5]
    X_fs[j][16] = X[i][6]
    X_fs[j][17] = X[i][7]
    j = j + 1;

print('\t\tFS Set created. Growing some trees!')





########################## CONVERTING TO GUASSIAN #####################################
print("\t\t Converting to Guassian")
X_rows,X_cols = X.shape
X_max = np.amax(X,axis = 0); #Max of columns
X_min = np.amin(X,axis = 0); #Min of columns
X_mean = (X_max + X_min)/2; #Middle values per column.
X_std = np.std(X,axis = 0);
X_guassian = np.zeros((X_rows, X_cols * 3));
for i in range(X_cols):
    for j in range(3):
        if j == 0:
            X_guassian[:,3*i + j] = X_guassian[:,3*i + j] + guassianFunction(X[:,i], 1, X_min[i], X_std[i])
        elif j == 1:
            X_guassian[:,3*i + j] = X_guassian[:,3*i + j] + guassianFunction(X[:,i], 1, X_mean[i], X_std[i])
        elif j == 2:
            X_guassian[:,3*i + j] = X_guassian[:,3*i + j] + guassianFunction(X[:,i], 1, X_max[i], X_std[i])

X_fs_rows,X_fs_cols = X_fs.shape
X_fs_max = np.amax(X_fs,axis = 0); #Max of columns
X_fs_min = np.amin(X_fs,axis = 0); #Min of columns
X_fs_mean = (X_fs_max + X_fs_min)/2; #Middle values per column.
X_fs_std = np.std(X_fs,axis = 0);
X_fs_guassian = np.zeros((X_fs_rows, X_fs_cols * 3));
for i in range(X_fs_cols):
    for j in range(3):
        if j == 0:
            X_fs_guassian[:,3*i + j] = X_fs_guassian[:,3*i + j] + guassianFunction(X_fs[:,i], 1, X_fs_min[i], X_fs_std[i])
        elif j == 1:
            X_fs_guassian[:,3*i + j] = X_fs_guassian[:,3*i + j] + guassianFunction(X_fs[:,i], 1, X_fs_mean[i], X_fs_std[i])
        elif j == 2:
            X_fs_guassian[:,3*i + j] = X_fs_guassian[:,3*i + j] + guassianFunction(X_fs[:,i], 1, X_fs_max[i], X_fs_std[i])



#################### Making some adjustments ##########################################
#Setting KFold Splitting and training data same in all runs - to avoid random errors
X_train,X_test,y_train,y_test = train_test_split(X_guassian, y , test_size = local_test_size)
kf = KFold(len(X_train),kFold, shuffle = True)


#################### Run - 1 - RS - Sensors ####################################
X_RS_train = X_train[:,:24]
X_RS_test = X_test[:,:24]
y_RS_train = y_train
y_RS_test = y_test
print('\t\tGrowing Trees on RS Feature Set')
cf.runClassifier(X_RS_test, X_RS_train, y_RS_test, y_RS_train, kf, tree)
print('\t\tGrowing Forests on RS Feature Set')
cf.runClassifier(X_RS_test, X_RS_train, y_RS_test, y_RS_train, kf, forest)


#################### Run - 2 - RSTH - Sensors ####################################
X_RSTH_train = X_train
X_RSTH_test = X_test
y_RSTH_train = y_train
y_RSTH_test = y_test
print('\t\tGrowing Trees on RSTH Feature Set')
cf.runClassifier(X_RSTH_test, X_RSTH_train, y_RSTH_test, y_RSTH_train, kf, tree)
print('\t\tGrowing Forests on RSTH Feature Set')
cf.runClassifier(X_RSTH_test, X_RSTH_train, y_RSTH_test, y_RSTH_train, kf, forest)


##################### Making some adjustments ##########################################
#Setting KFold Splitting and training data same in all runs - to avoid random errors
X_train,X_test,y_train,y_test = train_test_split(X_fs_guassian, y_fs , test_size = local_test_size)
kf = KFold(len(X_train),kFold, shuffle = True)


#################### Run - 3 - FS - Sensors ####################################
X_fs_train = X_train[:,:24]
X_fs_test = X_test[:,:24]
y_fs_train = y_train
y_fs_test = y_test
print('\t\tGrowing Trees on FS Feature Set')
cf.runClassifier(X_fs_test, X_fs_train, y_fs_test, y_fs_train, kf, tree)
print('\t\tGrowing Forests on FS Feature Set')
cf.runClassifier(X_fs_test, X_fs_train, y_fs_test, y_fs_train, kf, forest)


#################### Run - 4 - FSt0dt - Sensors ####################################
X_fst0dt_train = X_train[:,:30]
X_fst0dt_test = X_test[:,:30]
y_fst0dt_train = y_train
y_fst0dt_test = y_test
print('\t\tGrowing Trees on FSt0dt Feature Set')
cf.runClassifier(X_fst0dt_test, X_fst0dt_train, y_fst0dt_test, y_fst0dt_train, kf, tree)
print('\t\tGrowing Forests on FSt0dt Feature Set')
cf.runClassifier(X_fst0dt_test, X_fst0dt_train, y_fst0dt_test, y_fst0dt_train, kf, forest)


#################### Run - 5 - FSRS - Sensors ####################################
X_fsrs_train = np.append(X_train[:,:24], X_train[:,30:], axis = 1)
X_fsrs_test = np.append(X_test[:,:24], X_test[:,30:], axis = 1)
y_fsrs_train = y_train
y_fsrs_test = y_test
print('\t\tGrowing Trees on FSRS Feature Set')
cf.runClassifier(X_fsrs_test, X_fsrs_train, y_fsrs_test, y_fsrs_train, kf, tree)
print('\t\tGrowing Forests on FSRS Feature Set')
cf.runClassifier(X_fsrs_test, X_fsrs_train, y_fsrs_test, y_fsrs_train, kf, forest)
