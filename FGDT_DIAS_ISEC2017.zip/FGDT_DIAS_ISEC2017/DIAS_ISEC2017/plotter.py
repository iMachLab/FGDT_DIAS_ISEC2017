import pandas as pd
import numpy as np
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt
from sklearn.cross_validation import train_test_split
from sklearn.cross_validation import KFold
from math import exp
import classifier as cf




#Function to Plot Scatter plot
#X-Axis is t0
#Y-Axis is dt
def runScatterPlot(t0,dt,id_nos):

    x_banana = np.zeros(1)
    y_banana = np.zeros(1)
    x_wine = np.zeros(1)
    y_wine = np.zeros(1)
    x_background = np.zeros(1)
    y_background = np.zeros(1)

    for i in range(len(t0)):
        if (id_nos[i] == 2):
            x_banana = np.append(x_banana,t0[i])
            y_banana = np.append(y_banana,dt[i])
        elif (id_nos[i] == 1):
            x_wine = np.append(x_wine,t0[i])
            y_wine = np.append(y_wine,dt[i])
        else:
            x_background = np.append(x_background,t0[i])
            y_background = np.append(y_background,dt[i])

    x_banana = x_banana[1:]
    y_banana = y_banana[1:]
    x_wine = x_wine[1:]
    y_wine = y_wine[1:]
    x_background = x_background[1:]
    y_background = y_background[1:]

    plt.plot(x_banana, y_banana, 'ro', x_wine, y_wine, 'bs', x_background, y_background, 'g^')
    plt.draw()
    plt.show()

##################### End of Function Definition ############################
