import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from math import exp

def guassianFunction(x,a,b,c):
    guassian = np.zeros(x.shape);
    for i in range(x.size):
        guassian[i] = a * exp( -1 * ( x[i] - b )**2 / (2 * c * c))
    return guassian;


print('\t\tSetting up Data!')

#opening Sensor Data
with open('HT_Sensor_dataset.dat', 'r') as f:
    next(f)  #skip first row
    df = pd.DataFrame(l.rstrip().split() for l in f)

df = df.as_matrix()   #df contains the dataset.
#col 0 has id_nos, col 1 has time, col 2-9 has sensors r1 to r8
#col 10 has temp, col 11 has humidity.

#opening metadata and converting to usable form
metadata = np.loadtxt('HT_Sensor_metadata.dat', skiprows=1, dtype=str)
metadata[ metadata[:,2] == "b'wine'", 2 ] = 1
metadata[ metadata[:,2] == "b'banana'", 2 ] = 2
metadata[ metadata[:,2] == "b'background'", 2 ] = 0
id_nos = metadata[:,2].astype(np.double)
t0 = metadata[:,3]
dt = metadata[:,4]
#Converting metadata to usable form.
for i in range(len(t0)):
    t0[i] = t0[i][2:-1]
    dt[i] = dt[i][2:-1]

t0 = t0.astype(np.double)
dt = dt.astype(np.double)

#stripping X and y from df
y = df[:,0].astype(np.int);
y_copy = np.copy(y) #Copy needed During FS Set Creation
X = df[:,2:].astype(np.double); #Excluding Time columns, the second column in dataset

#replacing labels of y from id_nos.
for i in range(len(y)):
    y[i] = id_nos[ y[i] ]

X = df[:,2:].astype(np.double); #Excluding Time columns, the second column in dataset


print("\t\t Converting to Guassian")
X_rows,X_cols = X.shape
X_max = np.amax(X,axis = 0); #Max of columns
X_min = np.amin(X,axis = 0); #Min of columns
X_mean = (X_max + X_min)/2; #Middle values per column.
X_std = np.std(X,axis = 0);

#Creating guassianTransformed Dataset
X_guassian = np.zeros((X_rows, X_cols * 3));
for i in range(X_cols):
    for j in range(3):
        if j == 0:
            X_guassian[:,3*i + j] = X_guassian[:,3*i + j] + guassianFunction(X[:,i], 1, X_min[i], X_std[i])
        elif j == 1:
            X_guassian[:,3*i + j] = X_guassian[:,3*i + j] + guassianFunction(X[:,i], 1, X_mean[i], X_std[i])
        elif j == 2:
            X_guassian[:,3*i + j] = X_guassian[:,3*i + j] + guassianFunction(X[:,i], 1, X_max[i], X_std[i])



################################################################################################################################
################################################################################################################################
###### Plots how the graph for classification will look
###### Replace 0 with other features for other functions as well

x_range = np.linspace(X_min[0],X_max[0],1000 )
y_min = guassianFunction(x_range,1,X_min[0],X_std[0])
y_mean = guassianFunction(x_range,1,X_mean[0],X_std[0])
y_max = guassianFunction(x_range,1,X_max[0],X_std[0])

plt.plot(x_range, y_min, x_range, y_mean, x_range, y_max)
plt.draw()
plt.show()
