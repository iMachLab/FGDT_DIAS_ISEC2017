import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from math import exp

############################ Setting up Data ##################################
print('\t\tSetting up Data!')

#opening Sensor Data
with open('HT_Sensor_dataset.dat', 'r') as f:
    next(f)  #skip first row
    df = pd.DataFrame(l.rstrip().split() for l in f)

df = df.as_matrix()   #df contains the dataset.
#col 0 has id_nos, col 1 has time, col 2-9 has sensors r1 to r8
#col 10 has temp, col 11 has humidity.

#opening metadata and converting to usable form
metadata = np.loadtxt('HT_Sensor_metadata.dat', skiprows=1, dtype=str)
metadata[ metadata[:,2] == "b'wine'", 2 ] = 1
metadata[ metadata[:,2] == "b'banana'", 2 ] = 2
metadata[ metadata[:,2] == "b'background'", 2 ] = 0
id_nos = metadata[:,2].astype(np.double)


#stripping X and y from df
y = df[:,0].astype(np.int);
y_copy = np.copy(y) #Copy needed During FS Set Creation
X = df[:,2:].astype(np.double); #Excluding Time columns, the second column in dataset
#replacing labels of y from id_nos.
for i in range(len(y)):
    y[i] = id_nos[ y[i] ]

X = df[:,2:].astype(np.double); #Excluding Time columns, the second column in dataset


#====================== END OF DATA PREP ======================#
r1 = [];r2 = [];r3 = [];r4 = [];r5 = [];r6 = [];r7 = [];r8 = [];temp = [];hum = [];
id_array=[];
i = 0
while i < len(X):
    id_array.append(y[i])
    r1.append(X[i,0])
    r2.append(X[i,1])
    r3.append(X[i,2])
    r4.append(X[i,3])
    r5.append(X[i,4])
    r6.append(X[i,5])
    r7.append(X[i,6])
    r8.append(X[i,7])
    temp.append(X[i,8])
    hum.append(X[i,9])
    i = i + 1250

r1 = np.array(r1);r2 = np.array(r2);r3 = np.array(r3);r4 = np.array(r4);r5 = np.array(r5);r6 = np.array(r6);
r7 = np.array(r7);r8 = np.array(r8);temp = np.array(temp); hum = np.array(hum)
id_array = np.array(id_array)

#==============================================================#
r1_1=[];r2_1=[];r3_1=[];r4_1=[];r5_1=[];r6_1=[];r7_1=[];r8_1=[];temp_1=[];hum_1=[];
id_array_1=[];
r1_2=[];r2_2=[];r3_2=[];r4_2=[];r5_2=[];r6_2=[];r7_2=[];r8_2=[];temp_2=[];hum_2=[];
id_array_2=[];
r1_0=[];r2_0=[];r3_0=[];r4_0=[];r5_0=[];r6_0=[];r7_0=[];r8_0=[];temp_0=[];hum_0=[];
id_array_0=[];

for i in range(len(id_array)):
    if(id_array[i]==0):
        r1_0.append(r1[i])
        r2_0.append(r2[i])
        r3_0.append(r3[i])
        r4_0.append(r4[i])
        r5_0.append(r5[i])
        r6_0.append(r6[i])
        r7_0.append(r7[i])
        r8_0.append(r8[i])
        id_array_0.append(id_array[i])
        temp_0.append(temp[i])
        hum_0.append(hum[i])
    if(id_array[i]==1):
        r1_1.append(r1[i])
        r2_1.append(r2[i])
        r3_1.append(r3[i])
        r4_1.append(r4[i])
        r5_1.append(r5[i])
        r6_1.append(r6[i])
        r7_1.append(r7[i])
        r8_1.append(r8[i])
        id_array_1.append(id_array[i])
        temp_1.append(temp[i])
        hum_1.append(hum[i])
    if(id_array[i]==2):
        r1_2.append(r1[i])
        r2_2.append(r2[i])
        r3_2.append(r3[i])
        r4_2.append(r4[i])
        r5_2.append(r5[i])
        r6_2.append(r6[i])
        r7_2.append(r7[i])
        r8_2.append(r8[i])
        id_array_2.append(id_array[i])
        temp_2.append(temp[i])
        hum_2.append(hum[i])

#=======================================#

plt.plot(hum_1,r8_1,'bs',hum_2[100],r8_2[100],'g^')
plt.draw()
plt.show()
